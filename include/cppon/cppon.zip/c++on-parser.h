/*
 * C++ON - High performance C++17 JSON parser with extended features
 * https://github.com/methanium/cppon
 *
 * File: c++on-parser.h++ : JSON parsing and evaluation facilities
 *
 * MIT License
 * Copyright (c) 2023 Manuel Zaccaria (methanium) / CH5 Design
 *
 * See LICENSE file for complete license details
 */

#ifndef CPPON_PARSER_H
#define CPPON_PARSER_H

#include "c++on-types.h"
#include <array>

// Using this dynamic solution
#ifndef CPPON_NO_SIMD
    #include "../simd/simd_comparisons.h"  
    #include "../platform/processor_features_info.h"

    namespace cppon {
    namespace scanner {
        // Dynamic detection of SIMD capabilities
        enum class SimdLevel {
            None,
            SSE,
            AVX2,
            AVX512
        };

        inline SimdLevel detect_simd_level() {
            static SimdLevel cached_level = []() {
                platform::processor_features_info cpu_info;
                auto features = cpu_info.cpu_features();

                if (features.AVX512F)
                    return SimdLevel::AVX512;
                else if (features.AVX2)
                    return SimdLevel::AVX2;
                else if (features.SSE4_2)
                    return SimdLevel::SSE;
                else
                    return SimdLevel::None;
                }();
            return cached_level;
        }

        // Generic functions that select the appropriate SIMD implementation at runtime
        inline size_t find_quote_pos(std::string_view text, size_t start = 0) {
            switch (detect_simd_level()) {
            case SimdLevel::AVX512:
                return simd::zmm_parallel_find_quote_pos(text, start);
            case SimdLevel::AVX2:
                return simd::ymm_parallel_find_quote_pos(text, start);
            case SimdLevel::SSE:
                return simd::xmm_parallel_find_quote_pos(text, start);
            default:
                // Fallback version without SIMD
                return text.find('"', start);
            }
        }

        // Generic function for parsing digits
        inline const char* scan_digits(std::string_view text) {
            switch (detect_simd_level()) {
            case SimdLevel::AVX512:
                return simd::zmm_parallel_digits(text);
            case SimdLevel::AVX2:
                return simd::ymm_parallel_digits(text);
            case SimdLevel::SSE:
                return simd::xmm_parallel_digits(text);
            default:
                // Fallback version without SIMD
                const char* ptr = text.data();
                while (*ptr && std::isdigit(*ptr)) ptr++;
                return ptr;
            }
        }
    }
    }
#else
    // Implementations without SIMD
    namespace cppon {
    namespace scanner {
        inline size_t find_quote_pos(std::string_view text, size_t start = 0) {
            return text.find('"', start);
        }

        inline const char* scan_digits(std::string_view text) {
            const char* ptr = text.data();
            while (*ptr && std::isdigit(*ptr)) ptr++;
            return ptr;
        }
    }
    }
#endif

namespace cppon {

constexpr string_view_t path_prefix = CPPON_PATH_PREFIX;
constexpr string_view_t blob_prefix = CPPON_BLOB_PREFIX;
constexpr size_t object_min_reserve = CPPON_OBJECT_MIN_RESERVE;
constexpr size_t array_min_reserve = CPPON_ARRAY_MIN_RESERVE;

enum class options {
    full,  // full evaluation, with blob conversion
    eval,  // full evaluation, with conversion
    quick, // text evaluation (no conversion)
    parse  // parse only (validation)
};

constexpr options Full = options::full;
constexpr options Eval = options::eval;
constexpr options Quick = options::quick;
constexpr options Parse = options::parse;

namespace parser {
 
/**
 * @brief Encodes a blob into a base64 string.
 *
 * This function encodes a blob into a base64 string using the standard base64 encoding.
 *
 * @param Blob The blob to encode.
 * @return string_t The base64-encoded string.
 */
inline auto encode_base64(const blob_t& Blob) -> string_t {
    constexpr const std::array<char, 64> base64_chars{
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
    };

    string_t result;
    result.reserve((Blob.size() + 2) / 3 * 4);
    auto scan = Blob.data();
    auto end = scan + Blob.size();

    while (scan + 2 < end) {
        uint32_t buffer = (scan[0] << 16) | (scan[1] << 8) | scan[2];
        result.push_back(base64_chars[(buffer & 0x00FC0000) >> 18]);
        result.push_back(base64_chars[(buffer & 0x0003F000) >> 12]);
        result.push_back(base64_chars[(buffer & 0x00000FC0) >> 6]);
        result.push_back(base64_chars[(buffer & 0x0000003F)]);
        scan += 3;
    }

    if (scan < end) {
        uint32_t buffer = (scan[0] << 16);
        result.push_back(base64_chars[(buffer & 0x00FC0000) >> 18]);
        if (scan + 1 < end) {
            buffer |= (scan[1] << 8);
            result.push_back(base64_chars[(buffer & 0x0003F000) >> 12]);
            result.push_back(base64_chars[(buffer & 0x00000FC0) >> 6]);
            result.push_back('=');
        } else {
            result.push_back(base64_chars[(buffer & 0x0003F000) >> 12]);
            result.push_back('=');
            result.push_back('=');
        }
    }
    return result;
}

/**
 * @brief Decodes a base64 string into a blob.
 *
 * This function decodes a base64 string into a blob using the standard base64 decoding.
 *
 * @param Text The base64-encoded string to decode.
 * @param Raise Whether to raise an exception if an invalid character is encountered.
 * @return blob_t The decoded blob, or an empty blob if invalid and `Raise` is set to false.
 *
 * @throws invalid_base64_error if an invalid character is encountered and `Raise` is set to true.
 */
inline auto decode_base64(const string_view_t& Text, bool raise = true) -> blob_t {
    constexpr const std::array<uint8_t, 256> base64_decode_table{
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 0-15
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 16-31
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 62, 64, 64, 64, 63, // 32-47
        52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 64, 64, 64, 64, 64, // 48-63
        64,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, // 64-79
        15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 64, 64, 64, 64, 64, // 80-95
        64, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, // 96-111
        41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 64, 64, 64, 64, 64, // 112-127
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 128-143
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 144-159
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 160-175
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 176-191
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 192-207
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 208-223
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, // 224-239
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64  // 240-255
    };

    blob_t result;
    result.reserve((Text.size() + 3) / 4 * 3);
    auto scan = Text.data();
    auto end = scan + Text.size();

    while (scan < end) {
        uint32_t buffer = 0;
        int padding = 0;

        for (int i = 0; i < 4; ++i) {
            if (scan < end && *scan != '=') {
                uint8_t decoded_value = base64_decode_table[static_cast<uint8_t>(*scan)];
                if (decoded_value == 64) {
                    if (raise)
						throw invalid_base64_error{};
                    else
                        return blob_t{};
                }
                buffer = (buffer << 6) | decoded_value;
            } else {
                buffer <<= 6;
                ++padding;
            }
            ++scan;
        }

        result.push_back((buffer >> 16) & 0xFF);
        if (padding < 2) {
            result.push_back((buffer >> 8) & 0xFF);
        }
        if (padding < 1) {
            result.push_back(buffer & 0xFF);
        }
    }
	return result;
}

/**
 * @brief Converts a cppon value to its corresponding numeric type based on the specified NumberType.
 * 
 * This function uses std::visit to handle different types stored in the cppon variant. If the type is
 * number_t, it converts the string representation of the number to the appropriate numeric type based on
 * the NumberType enum. If the type is already a numeric type, no conversion is performed. If the type is
 * neither number_t nor a numeric type, a type_mismatch_error is thrown.
 *
 * @param value The cppon value to be converted. This value is modified in place.
 *
 * @throws type_mismatch_error if the value is neither number_t nor a numeric type.
 * @throws std::invalid_argument or std::out_of_range if the conversion functions (e.g., std::strtoll) fail.
 *
 * @note The function uses compiler-specific directives (__assume, __builtin_unreachable) to indicate that
 * certain code paths are unreachable, which can help with optimization and avoiding compiler warnings.
 */
inline void convert_to_numeric(cppon& value) {
    std::visit([&](auto&& arg) {
        using U = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<U, number_t>) {
            string_view_t str_value = static_cast<string_view_t>(arg);
            switch (arg.type) {
                case NumberType::json_int64:
                    value = static_cast<int64_t>(std::strtoll(str_value.data(), nullptr, 10));
                    break;
                case NumberType::json_double:
                    value = static_cast<double_t>(std::strtod(str_value.data(), nullptr));
                    break;
                case NumberType::cpp_float:
                    value = static_cast<float_t>(std::strtof(str_value.data(), nullptr));
                    break;
                case NumberType::cpp_int8:
                    value = static_cast<int8_t>(std::strtol(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_uint8:
                    value = static_cast<uint8_t>(std::strtoul(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_int16:
                    value = static_cast<int16_t>(std::strtol(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_uint16:
                    value = static_cast<uint16_t>(std::strtoul(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_int32:
                    value = static_cast<int32_t>(std::strtol(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_uint32:
                    value = static_cast<uint32_t>(std::strtoul(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_int64:
                    value = static_cast<int64_t>(std::strtoll(str_value.data(), nullptr, 10));
                    break;
                case NumberType::cpp_uint64:
                    value = static_cast<uint64_t>(std::strtoull(str_value.data(), nullptr, 10));
                    break;
                default:
                    #if defined(_MSC_VER)
                        __assume(false);
                    #elif defined(__GNUC__) || defined(__clang__)
                        __builtin_unreachable();
                    #else
                        std::terminate(); // Fallback for other platforms
                    #endif
            }
        } else if constexpr (std::is_arithmetic_v<U>) {
            // No-op if it's already a numeric type
        } else {
            throw type_mismatch_error{};
        }
    }, static_cast<value_t&>(value));
}

/**
 * @brief Checks if the given character is a space character.
 *
 * This function checks if the given character is a space character. It uses the standard library
 * `std::isspace` function if the CPPON_USE_TRUSTED directive is not set. Otherwise, it uses a
 * simple comparison to check if the character is a space.
 *
 * @param c The character to check.
 * @return bool True if the character is a space character, false otherwise.
 */
inline bool is_space(char c) {
    #if CPPON_USE_TRUSTED
    return (c + 1) < '\x22';
    #else
    return std::isspace(c);
    #endif
}

/**
 * @brief Skips any leading spaces in the given text.
 *
 * This function skips any leading spaces in the given text starting from the position specified by `Pos`.
 * It updates the `Pos` to point after the skipped spaces.
 *
 * @param text The text to skip spaces in.
 * @param pos The starting position in the text for skipping spaces.
 *            'Pos' is updated to point after the skipped spaces.
 * @param err The error message to throw if the end of the text is reached before finding a non-space character.
 *
 * @exception unexpected_end_of_text_error
 *            Thrown if the end of the text is reached before finding a non-space character.
 */
inline auto skip_spaces(string_view_t text, size_t& pos, const char* err) {
    auto scan{ text.data() + pos };
    if (*scan) {
        if (is_space(*scan)) {
            ++scan;
            while (is_space(*scan))
                ++scan;
            pos = scan - text.data();
        }
        if (*scan)
            return;
    }
    throw unexpected_end_of_text_error{ err };
}

/**
 * @brief Expects a specific character in the given text at the specified position.
 *
 * This function checks if the character at the specified position in the given text
 * matches the expected character.
 * If the characters do not match, an expected_symbol_error is thrown.
 *
 * @param text The text to check.
 * @param match The expected character.
 * @param pos The position in the text to check.
 *            'Pos' is updated to point to the next character after the expected character.
 *
 * @exception expected_symbol_error
 *            Thrown if the character at the specified position does not match the expected character.
 */
inline auto expect(string_view_t text, char match, size_t& pos) {
    auto scan{ text.data() + pos };
    if (*scan != match)
        throw expected_symbol_error{ string_view_t{ &match, 1 }, pos };
    ++pos;
}

/**
  * Forward declaration sor arrays and objects
  */
inline auto accept_value(string_view_t text, size_t& pos, options opt) -> cppon;

/**
 * @brief Accepts a specific entity ("null", "true", or "false") from the given text.
 *
 * This function accepts a specific entity from the given text at the specified position.
 * The entity can be one of the following: "null", "true", or "false".
 * The function updates the `Pos` to point to the next character after the accepted entity.
 *
 * @param Text The text to accept the entity from.
 * @param Pos The position in the text to start accepting the entity.
 *            `Pos` is updated to point to the next character after the accepted entity.
 * @return cppon An instance of `cppon` containing the accepted entity.
 *
 * @exception expected_symbol_error
 *            Thrown if the characters at the specified position is not a valid entity.
 */
inline auto accept_null(string_view_t text, size_t& pos) -> cppon {
    if (text.compare(pos, 4, "null") == 0) {
        pos += 4;
        return cppon{nullptr};
    }
    throw expected_symbol_error{"null", pos};
}
inline auto accept_true(string_view_t text, size_t& pos) -> cppon {
    if (text.compare(pos, 4, "true") == 0) {
        pos += 4;
        return cppon{true};
    }
    throw expected_symbol_error{"true", pos};
}
inline auto accept_false(string_view_t text, size_t& pos) -> cppon {
    if (text.compare(pos, 5, "false") == 0) {
        pos += 5;
        return cppon{false};
    }
    throw expected_symbol_error{"null", pos};
}

/**
 * @brief Extracts a string from a JSON text, handling escape sequences.
 *
 * This function analyzes the JSON text starting from the position specified by `pos`
 * to extract a string. It correctly handles escape sequences such as \" and \\",
 * allowing quotes and backslashes to be included in the resulting string. Other
 * escape sequences are left as is, without transformation.
 *
 * @param text The JSON text to analyze.
 * @param pos The starting position in the text for analysis.
 *            `pos` is updated to point after the extracted string at the end of the analysis.
 * @return cppon An instance of `cppon` containing the extracted string.
 *
 * @exception unexpected_end_of_text_error
 *            Thrown if the end of the text is reached before finding a closing quote.
 */
inline auto accept_string(string_view_t text, size_t& pos, options opt) -> cppon {
    /*< expect(text, '"', pos); already done in accept_value */
    ++pos; // Advance the position to skip the opening quote
    size_t peek, found = pos - 1;
    do {
        found = scanner::find_quote_pos(text, found + 1);

        // If no quote is found and the end of the text is reached, throw an error
        if (found == text.npos)
            throw unexpected_end_of_text_error{ "string" };
        // Check for escaped characters
        peek = found;
        while (peek != pos && text[peek - 1] == '\\')
            --peek;
    } while (found - peek & 1); // Continue if the number of backslashes is odd
    
    // Update the position to point after the closing quote
    peek = pos;
    pos = found + 1;

    // Return the extracted substring
    auto value = text.substr(peek, found - peek);

    if(!value.empty() && value.front() == '$') {
        // If the path prefix is found, return a path object
        if (value.rfind(path_prefix, 0) == 0)
		    return cppon{ path_t{ value.substr(path_prefix.size()) } };

        // If the blob prefix is found, return a blob object
        if (value.rfind(blob_prefix, 0) == 0) {
            if (opt == options::full)
                // If the full option is set, return a blob object with the decoded value
			    return cppon{ decode_base64(value.substr(blob_prefix.size())) };
		    else
                // Otherwise, return a blob object with the encoded value
			    return cppon{ blob_string_t{ value.substr(blob_prefix.size()) } };
        }
	}

    // Otherwise, return a string object
    return cppon{ value };
}

/**
 * @brief Accepts a number from the given text at the specified position.
 *
 * This function accepts a number from the given text at the specified position.
 * The function updates the `pos` to point to the next character after the accepted number.
 * It handles different numeric formats based on the provided options.
 *
 * @param text The text to accept the number from.
 * @param pos The position in the text to start accepting the number.
 *            `pos` is updated to point to the next character after the accepted number.
 * @param opt The options for parsing the number, which determine the parsing behavior.
 * @return cppon An instance of `cppon` containing the accepted number.
 *
 * @exception unexpected_end_of_text_error
 *            Thrown if the end of the text is reached before finding a valid number.
 * @exception unexpected_symbol_error
 *            Thrown if an unexpected symbol is encountered while parsing the number.
 *
 * @note This function supports parsing of integers, floating-point numbers, and scientific notation.
 *       It uses the `convert_to_numeric` function to convert the parsed string to the appropriate numeric type.
 *       Although `convert_to_numeric` can throw `type_mismatch_error`, it is impossible in the context of this function
 *       because the input is always a valid numeric string when this function is called.
 */
inline auto accept_number(string_view_t text, size_t& pos, options opt) -> cppon {
   /**
     * JSON compatible types:
     * 0: int64  (without  suffix)
     * 1: double (without  suffix, with decimal point or exponent, also for C++ types)
     * Not JSON compatible types (C++ types):
     * 2: float  (with f   suffix and with decimal point or exponent)
     * 3: int8   (with i8  suffix)
     * 4: uint8  (with u8  suffix)
     * 5: int16  (with i16 suffix)
     * 6: uint16 (with u16 suffix)
     * 7: int32  (with i32 suffix)
     * 8: uint32 (with u32 suffix)
     * 9: int64  (with i64 suffix)
     * 10:uint64 (with u64 suffix)
     */
    auto type = NumberType::json_int64;
    auto is_unsigned = false;
    auto has_suffix = false;
    auto start = pos;
    auto scan = &text[start];
    auto is_negative = scan[0] == '-';
    auto is_zero = scan[is_negative] == '0';

    scan += is_negative + is_zero;

    if (!is_zero) {
        scan = scanner::scan_digits({ scan, size_t(&text.back() - scan + 1u) });
    }
    if (!scan) throw unexpected_end_of_text_error{ "number" };
    if (!isdigit(scan[-1]))
        throw unexpected_symbol_error{ string_view_t{ &scan[-1], 1u }, size_t((scan - &text[start]) - 1u) };
    // scan decimal point
    if (*scan == '.' && isdigit(scan[1])) {
        // scan fractional part
        scan = scanner::scan_digits({ scan, size_t(&text.back() - scan + 1u) });
        if (!scan)
            throw unexpected_end_of_text_error{ "number" };
        type = NumberType::json_double; // double by default
    }
    else if (*scan == 'i' || *scan == 'I') {
        // scan unsigned flag
        ++scan;
        has_suffix  = true;
        is_unsigned = false;
    }
    else if (*scan == 'u' || *scan == 'U') {
        // scan unsigned flag
        ++scan;
        has_suffix  = true;
        is_unsigned = true;
    }
    // scan exponent
    if (!has_suffix && (*scan == 'e' || *scan == 'E')) {
        ++scan;
        // scan exponent sign
        if (*scan == '-' || *scan == '+') ++scan;
        // scan exponent digits
        while (isdigit(*scan))
            ++scan;
        if (!isdigit(scan[-1]))
            throw unexpected_symbol_error{ string_view_t{ &scan[-1], 1u },  size_t((scan - &text[pos]) - 1u) };
        type = NumberType::json_double; // double by default
    }
    if (type == NumberType::json_double && (*scan == 'f' || *scan == 'F')) {
		++scan;
		type = NumberType::cpp_float;
    }
    else if (has_suffix) {
        switch(*scan) {
        case '1': {
			++scan;
			if (!*scan)
				throw unexpected_end_of_text_error{ "number" };
			if (*scan != '6')
				throw unexpected_symbol_error{ string_view_t{ scan, 1u }, size_t(scan - &text[start]) };
			++scan;
			type = NumberType::cpp_int16;
			break;
        }
        case '3': {
			++scan;
			if (!*scan)
				throw unexpected_end_of_text_error{ "number" };
			if (*scan != '2')
				throw unexpected_symbol_error{ string_view_t{ scan, 1u }, size_t(scan - &text[start]) };
			++scan;
			type = NumberType::cpp_int32;
			break;
		}
        case '6': {
			++scan;
			if (!*scan)
				throw unexpected_end_of_text_error{ "number" };
			if (*scan != '4')
				throw unexpected_symbol_error{ string_view_t{ scan, 1u }, size_t(scan - &text[start]) };
			++scan;
			type = NumberType::cpp_int64;
			break;
		}
        case '8':
			++scan;
			type = NumberType::cpp_uint8;
			break;
        }
	    if (is_unsigned) {
            type = static_cast<NumberType>(static_cast<int>(type) + 1);
	    }
    }
    auto scan_size = scan - &text[start];
    pos += scan_size;

    cppon value{ number_t{ text.substr(start, scan_size), type } };

    if (opt < options::quick) // options:{full,eval}
        convert_to_numeric(value);

    return value;
}

/**
 * @brief Accepts an array from the given text at the specified position.
 *
 * This function accepts an array from the given text at the specified position.
 * An array can contain multiple values separated by commas.
 * The function updates the `pos` to point to the next character after the accepted array.
 *
 * @param text The text to accept the array from.
 * @param pos The position in the text to start accepting the array.
 *            `pos` is updated to point to the next character after the accepted array.
 * @param opt The options for parsing the array.
 * @return cppon An instance of `cppon` containing the accepted array.
 *
 * @exception unexpected_end_of_text_error
 *            Thrown if the end of the text is reached before finding a closing bracket for the array.
 * @exception unexpected_symbol_error
 *            Thrown if an unexpected symbol is encountered while parsing the array.
 */
inline auto accept_array(string_view_t text, size_t& pos, options opt) -> cppon {
    ++pos;
    skip_spaces(text, pos, "array");
    if (text[pos] == ']') {
        ++pos; // empty array
        return cppon{ array_t{} };
    }
    array_t array;
    if (opt != options::parse) // options:{eval,quick}
        array.reserve(array_min_reserve);
    do {
        skip_spaces(text, pos, "array");
        auto value = accept_value(text, pos, opt);
        skip_spaces(text, pos, "array");
        if (opt != options::parse) // options:{eval,quick}
            array.emplace_back(std::move(value));
    } while (text[pos] == ',' && ++pos);
    expect(text, ']', pos);
    return cppon{ std::move(array) };
}

/**
 * @brief Accepts an object from the given text at the specified position.
 *
 * This function accepts an object from the given text at the specified position.
 * An object contains key-value pairs separated by commas.
 * The function updates the `pos` to point to the next character after the accepted object.
 *
 * @param text The text to accept the object from.
 * @param pos The position in the text to start accepting the object.
 *            `pos` is updated to point to the next character after the accepted object.
 * @param opt The options for parsing the object.
 * @return cppon An instance of `cppon` containing the accepted object.
 *
 * @exception unexpected_end_of_text_error
 *            Thrown if the end of the text is reached before finding a closing brace for the object.
 * @exception unexpected_symbol_error
 *            Thrown if an unexpected symbol is encountered while parsing the object.
 */
inline auto accept_object(string_view_t text, size_t& pos, options opt) -> cppon {
     ++pos;
    skip_spaces(text, pos, "object");
    if (text[pos] == '}') {
        ++pos; // empty object
        return cppon{ object_t{} };
    }
    object_t object;
    if (opt != options::parse) // options:{eval,quick}
        object.reserve(object_min_reserve);
    do {
        skip_spaces(text, pos, "object");
        auto key = accept_string(text, pos, opt);
        skip_spaces(text, pos, "object");
        expect(text, ':', pos);
        skip_spaces(text, pos, "object");
        auto value = accept_value(text, pos, opt);
        skip_spaces(text, pos, "object");
        if (opt != options::parse) // options:{eval,quick}
            object.emplace_back(get<string_view_t>(key), std::move(value));
    } while (text[pos] == ',' && ++pos);
    expect(text, '}', pos);
    return cppon{ std::move(object) };
}

/**
 * @brief Accepts a value from the given text at the specified position.
 *
 * This function accepts a value from the given text at the specified position.
 * The value can be a string, number, object, array, true, false, or null.
 * The function updates the `pos` to point to the next character after the accepted value.
 *
 * @param text The text to accept the value from.
 * @param pos The position in the text to start accepting the value.
 *            `pos` is updated to point to the next character after the accepted value.
 * @param opt The options for parsing the value.
 * @return cppon An instance of `cppon` containing the accepted value.
 *
 * @exception unexpected_end_of_text_error
 *            Thrown if the end of the text is reached before finding a valid value.
 * @exception unexpected_symbol_error
 *            Thrown if an unexpected symbol is encountered while parsing the value.
 */
inline auto accept_value(string_view_t text, size_t& pos, options opt) -> cppon {
    switch (text[pos]) {
    case '"': return accept_string(text, pos, opt);
    case '{': return accept_object(text, pos, opt);
    case '[': return accept_array(text, pos, opt);
    case 'n': return accept_null(text, pos);
    case 't': return accept_true(text, pos);
    case 'f': return accept_false(text, pos);
    case '-': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
        return accept_number(text, pos, opt);
    default:
        throw unexpected_symbol_error{ text.substr(0, 1), pos };
    }
}

/**
 * @brief Evaluates a JSON text and returns the corresponding cppon structure.
 *
 * This function evaluates a JSON text and returns the corresponding cppon structure.
 * The JSON text is passed as a string view, and the options parameter allows for different
 * evaluation modes: Eval (full evaluation), Quick (text evaluation without conversion), and
 * Parse (parse only for validation).
 *
 * @param text The JSON text to evaluate.
 * @param opt The options for evaluating the JSON text. Default is Eval.
 * @return cppon The cppon structure representing the evaluated JSON text.
 */
inline auto eval(string_view_t text, options opt = Eval) -> cppon {
    if (text.empty())
        return cppon{ nullptr };
    
    if (text.size() >= 4 &&
        ((static_cast<unsigned char>(text[0]) == 0x00 && static_cast<unsigned char>(text[1]) == 0x00 &&
          static_cast<unsigned char>(text[2]) == 0xFE && static_cast<unsigned char>(text[3]) == 0xFF) ||
         (static_cast<unsigned char>(text[0]) == 0xFF && static_cast<unsigned char>(text[1]) == 0xFE &&
          static_cast<unsigned char>(text[2]) == 0x00 && static_cast<unsigned char>(text[3]) == 0x00))) {
        // UTF-32 BOM (not supported)
        throw unexpected_utf32_BOM_error{};
    }
    if (text.size() >= 2 &&
        // UTF-16 BOM (not supported)
        ((static_cast<unsigned char>(text[0]) == '\xFE' && static_cast<unsigned char>(text[1]) == '\xFF') ||
         (static_cast<unsigned char>(text[0]) == '\xFF' && static_cast<unsigned char>(text[1]) == '\xFE'))) {
        throw unexpected_utf16_BOM_error{};
    }
    if ((static_cast<unsigned char>(text[0]) & 0xF8) == 0xF8) {
        // 5 or 6 byte sequence, not valid in UTF-8
        throw invalid_utf8_sequence_error{};
    }
    if ((static_cast<unsigned char>(text[0]) & 0xC0) == 0x80) {
        // continuation byte, not valid as first byte
        throw invalid_utf8_continuation_error{};
    }

    // At this point, only valid UTF-8 sequences remain:
    //   - ASCII bytes     (0xxxxxxx)       : (text[0] & 0x80) == 0x00
    //   - 2-byte sequence (110xxxxx)       : (text[0] & 0xE0) == 0xC0
    //   - 3-byte sequence (1110xxxx)       : (text[0] & 0xF0) == 0xE0
    //   - 4-byte sequence (11110xxx)       : (text[0] & 0xF8) == 0xF0

    // accept UTF-8 BOM
    if (text.size() >= 3 && 
        static_cast<unsigned char>(text[0]) == '\xEF' && 
        static_cast<unsigned char>(text[1]) == '\xBB' && 
        static_cast<unsigned char>(text[2]) == '\xBF') {
        text.remove_prefix(3);
    }

    size_t pos{};
    skip_spaces(text, pos, "eval");

    // accept any value, not object only
    return accept_value(text, pos, opt);
}

/**
 * @brief Retrieves the blob data from a cppon object.
 *
 * This function attempts to retrieve the blob data from a given cppon object. If the object contains a `blob_string_t`,
 * it decodes the base64 string into a `blob_t` and updates the cppon object. If the object already contains a `blob_t`,
 * it simply returns it. If the object contains neither, it throws a `type_mismatch_error`.
 *
 * @param value The cppon object from which to retrieve the blob data.
 * @param raise Whether to raise an exception if base64 decoding fails. If false, returns an empty blob instead.
 *              Defaults to true.
 * @return A reference to the blob data contained within the cppon object.
 *
 * @exception type_mismatch_error Thrown if the cppon object does not contain a `blob_string_t` or `blob_t`.
 * @exception invalid_base64_error Thrown if the base64 string is invalid and `raise` is set to true.
 */
inline blob_t& get_blob(cppon& value, bool raise = true) {
    return std::visit([&](auto&& arg) -> blob_t& {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, blob_string_t>) {
            value = decode_base64(arg, raise);
            return std::get<blob_t>(value);
        }
        else if constexpr (std::is_same_v<T, blob_t>) {
            return arg;
        }
        else {
            throw type_mismatch_error{};
        }
        }, static_cast<value_t&>(value));
}

/**
 * @brief Retrieves a constant reference to blob data from a cppon object.
 *
 * This function attempts to retrieve a constant reference to the blob data from a given cppon object.
 * Unlike the non-const version, this function does not perform any conversion of `blob_string_t` to `blob_t`.
 * If the object contains a `blob_t`, it returns a reference to it. If the object contains a `blob_string_t`,
 * it throws a `blob_not_realized_error` since the blob must be decoded first. For all other types, it throws
 * a `type_mismatch_error`.
 *
 * @param value The cppon object from which to retrieve the blob data.
 * @return A constant reference to the blob data contained within the cppon object.
 *
 * @exception type_mismatch_error Thrown if the cppon object does not contain a `blob_t` or `blob_string_t`.
 * @exception blob_not_realized_error Thrown if the cppon object contains a `blob_string_t` (not yet decoded).
 */
inline const blob_t& get_blob(const cppon& value) {
    return std::visit([](const auto& arg) -> const blob_t& {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, blob_string_t>) {
            throw blob_not_realized_error{};
        }
        else if constexpr (std::is_same_v<T, blob_t>) {
            return arg;
        }
        else {
            throw type_mismatch_error{};
        }
        }, static_cast<const value_t&>(value));
}

/**
 * @brief Retrieves a value of type T from a cppon value, ensuring strict type matching.
 *
 * This function attempts to retrieve a value of type T from the cppon variant. If the value is of type
 * number_t, it first converts it to the appropriate numeric type using convert_to_numeric. If the value
 * is already of type T, it is returned directly. If the value is of a different type, a type_mismatch_error
 * is thrown.
 *
 * @tparam T The type to retrieve. Must be a numeric type.
 * @param value The cppon value from which to retrieve the type T value.
 * @return T The value of type T.
 *
 * @throws type_mismatch_error if the value is not of type T or cannot be converted to type T.
 *
 * @note This function uses std::visit to handle different types stored in the cppon variant.
 */
template<typename T>
inline T get_strict(cppon& value) {
    static_assert(std::is_arithmetic_v<T>, "T must be a numeric type");
    return std::visit([&](auto&& arg) -> T {
        using type = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<type, number_t>) {
            convert_to_numeric(value);
            return get_strict<T>(value);
        }
        else if constexpr (std::is_same_v<type, T>) {
            return arg;
        }
        else {
            throw type_mismatch_error{};
        }
        }, static_cast<value_t&>(value));
}

template<typename T>
inline T get_strict(const cppon& value) {
    static_assert(std::is_arithmetic_v<T>, "T must be a numeric type");
    return std::visit([&](const auto& arg) -> T {
        using type = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<type, number_t>) {
            throw number_not_converted_error{};
        }
        else if constexpr (std::is_same_v<type, T>) {
            return arg;
        }
        else {
            throw type_mismatch_error{};
        }
        }, static_cast<const value_t&>(value));
}

/**
 * @brief Retrieves a value of type T from a cppon value, allowing type casting.
 *
 * This function attempts to retrieve a value of type T from the cppon variant. If the value is of type
 * number_t, it first converts it to the appropriate numeric type using convert_to_numeric. If the value
 * is of a different numeric type, it is cast to type T. If the value is of a non-numeric type, a
 * type_mismatch_error is thrown.
 *
 * @tparam T The type to retrieve. Must be a numeric type.
 * @param value The cppon value from which to retrieve the type T value.
 * @return T The value of type T.
 *
 * @throws type_mismatch_error if the value is not a numeric type and cannot be cast to type T.
 *
 * @note This function uses std::visit to handle different types stored in the cppon variant.
 */
template<typename T>
inline T get_cast(cppon& value) {
    static_assert(std::is_arithmetic_v<T>, "T must be a numeric type");
    return std::visit([&](auto&& arg) -> T {
        using type = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<type, number_t>) {
            convert_to_numeric(value);
            return get_cast<T>(value);
        }
        else if constexpr (std::is_arithmetic_v<type>) {
            return static_cast<T>(arg);
        }
        else {
            throw type_mismatch_error{};
        }
        }, static_cast<value_t&>(value));
}

template<typename T>
inline T get_cast(const cppon& value) {
    static_assert(std::is_arithmetic_v<T>, "T must be a numeric type");
    return std::visit([&](auto&& arg) -> T {
        using type = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<type, number_t>) {
            throw number_not_converted_error{};
        }
        else if constexpr (std::is_arithmetic_v<type>) {
            return static_cast<T>(arg);
        }
        else {
            throw type_mismatch_error{};
        }
        }, static_cast<value_t&>(value));
}

template<typename T>
constexpr inline T* get_optional(cppon& value) noexcept {
    return std::get_if<T>(value);
}

template<typename T>
constexpr inline const T* get_optional(const cppon& value) noexcept {
    return std::get_if<T>(value);
}

}//namespace parser

using parser::eval;
using parser::get_blob;
using parser::get_strict;
using parser::get_cast;
using parser::get_optional;

}//namespace cppon

#endif // CPPON_PARSER_H