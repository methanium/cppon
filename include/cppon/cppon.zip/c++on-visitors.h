/*
 * C++ON - High performance C++17 JSON parser with extended features
 * https://github.com/methanium/cppon
 *
 * File: c++on-visitors.h++ : Object traversal and manipulation utilities
 *
 * MIT License
 * Copyright (c) 2023 Manuel Zaccaria (methanium) / CH5 Design
 *
 * See LICENSE file for complete license details
 */

#ifndef CPPON_VISITORS_H
#define CPPON_VISITORS_H

#include "c++on-types.h"
#include <algorithm>
#include <stack>

namespace cppon {

constexpr size_t max_array_delta = CPPON_MAX_ARRAY_DELTA;

/**
 * @brief Central utilities for managing cppon objects and their interconnections.
 *
 * This suite of utility functions is foundational to the cppon framework, offering mechanisms for managing the root object,
 * handling null values, and processing reference paths during deserialization. These utilities ensure the cppon object hierarchy
 * remains coherent, navigable, and dynamically adaptable, supporting complex data structures and relationships.
 *
 * - `null()`: Provides a singleton instance representing a null value, ensuring consistent representation of null or undefined
 *   states across the cppon object hierarchy.
 *
 * - `get_root()`, `set_root(cppon&)`, and `reset_root()`: Facilitate the management of the root object, which is pivotal for
 *   resolving reference paths and maintaining the top-level context of the cppon hierarchy. These functions allow for dynamic
 *   adjustments to the root object, accommodating changes in the object hierarchy's structure.
 *
 * - `is_root(const cppon&)` and `is_null_root()`: Offer checks to determine if a given cppon object is the current root or if
 *   the root is set to the null singleton, respectively. These checks are crucial for operations that depend on the position
 *   of objects within the hierarchy.
 *
 * - `root_storage()`: Provide access to the storage location for the root object of the cppon namespace.
 *
 * Collectively, these utilities underscore the cppon framework's flexibility, robustness, and capability to represent and manage
 * complex data structures and relationships. They are instrumental in ensuring that cppon objects can be dynamically linked,
 * accessed, and manipulated within a coherent and stable framework.
 */
#ifndef CPPON_ROOT_STACK
inline cppon& null() noexcept {
	static thread_local cppon Null{ nullptr };
	return Null;
}
inline cppon*& root_storage() noexcept {
	static thread_local cppon* root = &null();
    return root;
 }
 inline bool is_root(const cppon& root) noexcept {
     return root_storage() == &root;
 }
 inline void set_root(cppon& root) noexcept {
     root_storage() = &root;
 }
 inline void reset_root() noexcept {
    root_storage() = &null();
 }
 inline bool is_null_root() noexcept {
     return root_storage() == &null();
 }
 inline cppon& get_root() noexcept {
     return *root_storage();
 }
#else
struct static_storage {
	static_storage() noexcept : stack{ std::deque<cppon*>{nullptr} }, Null{ nullptr } {}
	std::stack<cppon*> stack;
	cppon Null;
};
inline static_storage& get_static_storage() noexcept {
	static thread_local static_storage storage;
	return storage;
}
inline cppon& null() noexcept {
	return get_static_storage().Null;
}
inline std::stack<cppon*>& root_stack() noexcept {
	return get_static_storage().stack;
}
inline cppon& get_root() noexcept {
	return *root_stack().top();
}
inline void pop_root(const cppon& root) noexcept {
	auto& stack = root_stack();
	auto top = &const_cast<cppon&>(root);
	if (stack.top() == top) stack.pop();
}
inline void push_root(const cppon& root) {
	auto& stack = root_stack();
	auto top = &const_cast<cppon&>(root);
	if (stack.top() != top) stack.push(top);
}
#endif



/**
 * @brief Dynamically accesses elements within a cppon object using a string index, with support for both const and non-const contexts.
 *
 * This function allows dynamic access to elements within a cppon object, which can be either an array or an object,
 * using a string index. The string index can represent either a direct key in an object or a numeric index in an array.
 * 
 * Additionally, it supports hierarchical access to nested elements by interpreting the string index as a path, where segments
 * of the path are separated by slashes ('/'). This allows deep access to nested structures, with the non-const version
 * allowing modification of elements.
 *
 * The function first determines the type of the cppon object (array or object) based on its current state. It then attempts
 * to access the element specified by the index or path. If the element is within a nested structure, the function recursively
 * navigates through the structure to reach the desired element. In the non-const version, any missing elements along the path
 * are created as either objects or arrays, depending on the segment type.
 *
 * Exceptions:
 * - `type_mismatch_error` is thrown if the object is not an array or an object when expected.
 * - In the const version:
 *   - If the key is a path, `member_not_found_error`, `invalid_path_segment_error`, or `type_mismatch_error` may be thrown depending on the path.
 *   - If the key is a numeric value, `member_not_found_error` is thrown for object_t, and `invalid_path_segment_error` may be thrown for array_t.
 *   - When reaching the leaf of the path in an object_t and the member does not exist, it returns the null object, avoiding exceptions for non-existent members in read-only scenarios.
 *   - If the path segment is not a number, `invalid_path_segment_error` is thrown.
 *   - If the index is out of bounds for the array, it returns the null object.
 * - In the non-const version:
 *   - If the path exists and the current segment is a number for object_t, it throws `member_not_found_error` or `type_mismatch_error`.
 *   - If the index is a string segment that does not resolve to a number, it will throw `invalid_path_segment_error`.
 *   - If the index is out of bounds for the array and requires excessive resizing, it throws `excessive_array_resize_error`.
 *
 * This ensures that the caller is informed of incorrect access attempts or structural issues within the cppon object.
 *
 * The const version of this function provides the same functionality but ensures that the operation does not modify the object
 * being dereferenced. It allows dynamic dereferencing of objects in a const context, supporting scenarios where the cppon object
 * structure is accessed in a read-only manner.
 *
 * @param object The cppon object to visit. This object can be an array or an object, and may contain nested structures.
 * 
 * @param index A string representing the index or path to the element to access. This can specify direct access or hierarchical access to nested elements.
 * 
 * @return (const) cppon& A reference to the cppon element at the specified index or path, with the non-const version allowing modification of the element.
 * 
 * @throws type_mismatch_error If the cppon object does not match the expected structure for the specified index or path, indicating a type mismatch or invalid access attempt.
 * @throws member_not_found_error In the specified scenarios, indicating that a specified member in the path does not exist.
 * @throws invalid_path_segment_error In the specified scenarios, indicating that a path segment is invalid or out of bounds.
 * @throws excessive_array_resize_error In the specified scenarios, indicating that excessive array resizing is required.
 */
inline auto deref_if_ptr(cppon& obj) -> cppon& {
	return std::visit([&](auto&& arg) -> cppon& {
		using type = std::decay_t<decltype(arg)>;
		if constexpr (std::is_same_v<type, pointer_t>)
			return arg ? *arg : null();
		if constexpr (std::is_same_v<type, path_t>)
			return visitor(get_root(), arg);
		return obj;
	}, static_cast<value_t&>(obj));
}

inline auto deref_if_ptr(const cppon& obj) -> const cppon& {
	return std::visit([&](auto&& arg) -> const cppon& {
		using type = std::decay_t<decltype(arg)>;
		if constexpr (std::is_same_v<type, pointer_t>)
			return arg ? *arg : null();
		if constexpr (std::is_same_v<type, path_t>)
			return visitor(get_root(), arg);
		return obj;
	}, static_cast<const value_t&>(obj));
}

/**
 * @brief Dynamically accesses elements within an array by numerical index, with support for optional array expansion.
 *
 * These specializations of the visitor function serve a dual purpose within the cppon framework. They allow for direct access
 * to elements within an array by their numerical index. The non-const version additionally supports dynamically resizing the array
 * to accommodate indices beyond the current bounds, facilitating the mutation of the array structure. This dynamic resizing is
 * constrained by a permissible range, defined by the current size plus a max_array_delta threshold, to prevent excessive expansion.
 *
 * The const version of the function provides read-only access to elements within a constant array, ensuring that the operation does not
 * modify the array. It checks if the requested index is within the bounds of the array and returns a reference to the element at that
 * index. If the index is out of bounds, a null object is returned, indicating that the element does not exist at the specified index.
 *
 * Both versions of the function play crucial roles in accessing and potentially modifying arrays within the cppon data structure,
 * allowing for efficient and safe retrieval or modification of elements by their numerical index. They support accessing deeply nested
 * objects or pointed-to objects within the cppon structure, facilitating complex data manipulation and access patterns.
 *
 * Note that the non-const version is the source of `excessive_array_resize_error` if the requested index exceeds the permissible range
 * (current size + max_array_delta). Both versions call `deref_if_ptr`, which can trigger a chain of recursion, potentially leading to
 * further exceptions depending on the structure of the cppon object.
 *
 * @param array The array to be accessed or modified. This array can be dynamically resized by the non-const version to accommodate
 *              new elements, within the limits of the max_array_delta constraint.
 * @param index The numerical index of the element to access. For the non-const version, if the index exceeds the current size of the
 *              array, the array is resized to accommodate the new element. For the const version, the index should be within the bounds
 *              of the array.
 * @return (const) cppon& A (constant) reference to the element at the specified index, allowing for direct access and, in the case of
 *         the non-const version, modification. The function ensures that the returned element is dereferenced if it represents a pointer
 *         or a reference, making it immediately usable.
 * @throws excessive_array_resize_error If the requested index exceeds the permissible range (current size + max_array_delta) in the non-const version.
 * @throws type_mismatch_error If a non-terminal path segment is not of type array or object.
 */
inline cppon& visitor(array_t& array, size_t index) {
	if (index >= array.size() ) {
		if (index > array.size()  + max_array_delta)
			throw excessive_array_resize_error();
		array.resize(index + 1, null());
	}
	return array[index];
}
inline const cppon& visitor(const array_t& array, size_t index) {
	if (index >= array.size()) {
		return null();
	}
	return array[index];
}

/**
 * @brief Visitor functions for accessing and potentially modifying elements in an array using a string index.
 *
 * These specializations of the visitor function enable access to elements within an array by interpreting
 * a string index as a numerical index or a path to nested elements. They support dynamic and flexible access
 * to array elements, allowing for both retrieval and modification of the elements. These functions are particularly
 * useful for accessing elements in nested structures within an array, providing a mechanism to navigate through
 * the array and its nested elements using a string-based path.
 *
 * The string index is interpreted as a path, where any leading '/' has already been processed by the operator[] to determine
 * if the path is absolute or relative. These functions search for the next '/' character in the index to determine if the
 * index represents a direct numerical index or a path to a nested element. The initial segment of the index (up to the next '/')
 * is interpreted as a numerical index, which is used to access the corresponding element within the array.
 *
 * If the index is purely numerical (no further '/' characters), these functions directly access the specified
 * element within the array. If the index represents a path (contains additional '/' characters), these functions
 * recursively navigate to the nested element specified by the remaining path, allowing for deep access into
 * nested arrays or objects.
 *
 * In the non-const variant, the function can dynamically expand the array to accommodate new indices beyond
 * the current size, thus avoiding 'out of bounds' errors. This behavior allows for the addition of new elements
 * at specified indices, enhancing the array's flexibility and usability in dynamic contexts.
 *
 * These functions throw a `invalid_path_segment_error` if the segment of the index cannot be converted to a valid
 * numerical index, ensuring that only valid indices are used for accessing or modifying the array. Additionally,
 * during recursive access, further exceptions may be thrown if nested paths are invalid or lead to inaccessible
 * elements, making it essential to handle exceptions appropriately when using these functions for deep access.
 *
 * Note that these functions traverse a segment or return a terminal element but call the main `visitor` function
 * for further processing.
 *
 * @param array The array to visit. This array may contain nested arrays and objects, allowing for hierarchical access.
 * @param index A string representing the numerical index or path to the element to access. This can specify direct access
 *              to an element by its numerical index or hierarchical access to nested elements within the array.
 * @return (const) cppon& A (constant) reference to the visited element in the array. Allows for modification of the element,
 *         supporting dynamic manipulation of the array's contents.
 * @throws invalid_path_segment_error If the immediate index is not numeric, indicating an invalid access attempt. Further exceptions
 *         may be thrown during recursive access if nested paths are invalid or lead to inaccessible elements.
 * @throws type_mismatch_error If a non-terminal path segment is not of type array or object.
 */
inline auto visitor(const array_t& array, string_view_t index) -> const cppon& {
	auto next{ index.find('/') };
	auto digits{ index.substr(0, next) };

	if (!std::all_of(digits.begin(), digits.end(), ::isdigit))
		bad_array_index_error(digits);

	// index is a number

    auto& element = visitor(array, std::stoi(digits.data()));

	// if there is no next segment, it's a value
	if (next == index.npos) {
		// thus return the value const reference
		return element;
	}

	// if there is a next segment, it's a path

	auto& value = deref_if_ptr(element);

	// if the value not defined or null, throw an error
	if (value.is_null())
		throw null_value_error();

	// recursive call to object or array
	return visitor(value, index.substr(next + 1));
}
inline auto visitor(array_t& array, string_view_t index) -> cppon& {
	auto next{ index.find('/') };
	auto digits{ index.substr(0, next) };

	if (!std::all_of(digits.begin(), digits.end(), ::isdigit))
		bad_array_index_error(digits);

	// index is a number

    auto& element = visitor(array, std::stoi(digits.data()));

	// if there is no next segment, it's a value
	if (next == index.npos) {
		// thus return the value reference
		return element;
	}

	// if there is a next segment, it's a path

	auto& value = deref_if_ptr(element);

	auto newIndex{ index.substr(next + 1) };
	auto nextKey{ newIndex.substr(0, newIndex.find('/')) };

	if (value.is_null())
		// if the value is null, create a new object or array
		// depending on the next key
		// if the next key is a number, create an array
		// if the next key is a string, create an object
		// and assign it to the value
		if ( std::all_of(nextKey.begin(), nextKey.end(), ::isdigit) )
			// next key is a number
			value = cppon{ array_t{} };
		else
			// next key is a string
			value = cppon{ object_t{} };

	// recursive call to object or array
	return visitor(value, newIndex);
}

/**
 * @brief Visitor functions for accessing and potentially modifying elements in an object using a string index.
 *
 * These specializations of the visitor function enable access to elements within an object by interpreting
 * a string index as a key or a path to nested elements. They support dynamic and flexible access
 * to object elements, allowing for both retrieval and modification of the elements. These functions are particularly
 * useful for accessing elements in nested structures within an object, providing a mechanism to navigate through
 * the object and its nested elements using a string-based path.
 *
 * The string index is interpreted as a path, where any leading '/' has already been processed by the operator[] to determine
 * if the path is absolute or relative. These functions search for the next '/' character in the index to determine if the
 * index represents a direct key or a path to a nested element. The initial segment of the index (up to the next '/')
 * is interpreted as a key, which is used to access the corresponding element within the object.
 *
 * If the index is purely a key (no further '/' characters), these functions directly access the specified
 * element within the object. If the index represents a path (contains additional '/' characters), these functions
 * recursively navigate to the nested element specified by the remaining path, allowing for deep access into
 * nested objects or arrays.
 *
 * In the non-const variant, the function can dynamically expand the object to accommodate new keys beyond
 * the current size, thus avoiding 'out of bounds' errors. This behavior allows for the addition of new elements
 * at specified keys, enhancing the object's flexibility and usability in dynamic contexts.
 *
 * These functions throw a `invalid_path_segment_error` if the initial segment of the index cannot be converted to a
 * valid key, ensuring that only valid keys are used for accessing or modifying the object. Additionally,
 * during recursive access, further exceptions may be thrown if nested paths are invalid or lead to inaccessible elements,
 * making it essential to handle exceptions appropriately when using these functions for deep access.
 *
 * Note that these functions traverse a segment or return a terminal element for an `object_t`.
 *
 * @param object The object to visit. This object may contain nested objects and arrays, allowing for hierarchical access.
 * @param index A string representing the key or path to the element to access. This can specify direct access
 *              to an element by its key or hierarchical access to nested elements within the object.
 * @return cppon& A reference to the visited element in the object. Allows for modification of the element, supporting dynamic
 *         manipulation of the object's contents.
 * @throws invalid_path_segment_error If the immediate index is not a valid key, indicating an invalid access attempt. Further exceptions
 *         may be thrown during recursive access if nested paths are invalid or lead to inaccessible elements.
 * @throws type_mismatch_error If a non-terminal path segment is not of type array or object.
 */
inline const cppon& visitor(const object_t& object, string_view_t index) {
	auto next{ index.find('/') };
	auto key = index.substr(0, next);

	for (auto& [name, value] : object) {
		if (name == key) {
			// if there is no next segment, it's a key, else it's a path
			return (next != index.npos) ? visitor(deref_if_ptr(value), index.substr(next + 1)) : value;
		}
	}

	// member not found

	// if there is no next segment, it's a key
	if (next == index.npos)
		// terminal segment, return null
		return null();

	// if there is a next segment, it's a path, thus throw member_not_found_error
	throw member_not_found_error{};
}
inline cppon& visitor(object_t& object, string_view_t index) {
	auto next{ index.find('/') };
	auto key = index.substr(0, next);

	for (auto& [name, value] : object) {
		if (name == key) {
			// if there is no next segment, it's a key, else it's a path
			return (next != index.npos) ? visitor(deref_if_ptr(value), index.substr(next + 1)) : value;
		}
	}

	// key doesn't exist yet

	// if there is no next segment, it's a key
	if (next == index.npos) {
		object.emplace_back(key, null());
		return get<cppon>(object.back());
	}

	// if there is a next segment, it's a path
	auto newIndex{ index.substr(next + 1) };
	auto nextKey{ newIndex.substr(0, newIndex.find('/')) };

	if ( std::all_of(nextKey.begin(), nextKey.end(), ::isdigit) )
		// next key is a number
		object.emplace_back(key, cppon{ array_t{} });
	else
		// next key is a string
		object.emplace_back(key, cppon{ object_t{} });

	// recursive call to object or array
	return visitor(get<cppon>(object.back()), newIndex);
}

/**
 * @brief Visitor functions for accessing and potentially modifying elements within a cppon object by a numerical index.
 *
 * These functions facilitate direct access to elements within a cppon object, which is expected to be an array,
 * using a numerical index. They are designed to handle both const and non-const contexts, allowing for read-only or
 * modifiable access to the elements, respectively.
 *
 * In the non-const version, if the specified index exceeds the current size of the array, the array is automatically resized
 * to accommodate the new element at the given index. This resizing is subject to a maximum increment limit defined by max_array_delta to prevent
 * excessive and potentially harmful allocation. If the required increment to accommodate the new index exceeds this limit, a bad_array_index_error exception is thrown,
 * signaling an attempt to access or create an element at an index that would require an excessively large increase in the array size.
 *
 * In both versions, if the cppon object is not an array (indicating a misuse of the type), a type_mismatch_error exception is
 * thrown. This ensures that the functions are used correctly according to the structure of the cppon object and maintains type safety.
 *
 * The const version of these functions provides read-only access to the elements, ensuring that the operation does not modify the
 * object being accessed. It allows for dynamic dereferencing of objects within a const context, supporting scenarios where the
 * cppon object structure is accessed in a read-only manner.
 *
 * Key Points:
 * - Direct access to elements by numerical index.
 * - Automatic resizing of the array in the non-const version to accommodate new elements, with a safeguard increment limit (max_array_delta).
 * - Throws excessive_array_resize_error if the required increment to reach the specified index exceeds the permissible range.
 * - Throws type_mismatch_error if the cppon object is not an array.
 * - Supports both const and non-const contexts, enabling flexible data manipulation and access patterns.
 *
 * @param object The cppon object to visit. This object must be an array for index-based access to be valid.
 * @param index The numerical index to access the element. In the non-const version, if the index is greater than the size of the array, the array is resized according to the increment limit.
 * @return (const) cppon& A reference to the visited element in the array. The non-const version allows for modification of the element.
 * @throws excessive_array_resize_error If the required increment to accommodate the specified index exceeds the maximum limit allowed by max_array_delta.
 * @throws type_mismatch_error If the cppon object is not an array, indicating a type error.
 */
inline const cppon& visitor(const cppon& object, size_t index) {
    return std::visit([&](auto&& arg) -> const cppon& {
		using type = std::decay_t<decltype(arg)>;
		if constexpr (std::is_same_v<type, array_t>)
			return visitor(arg, index);
		throw type_mismatch_error{};
    }, static_cast<const value_t&>(object));
}
inline cppon& visitor(cppon& object, size_t index) {
    return std::visit([&](auto&& arg) -> cppon& {
		using type = std::decay_t<decltype(arg)>;
		if constexpr (std::is_same_v<type, array_t>)
			return visitor(arg, index);
		throw type_mismatch_error{};
    }, static_cast<value_t&>(object));
}

/**
 * @brief Dynamically accesses elements within a cppon object using a string index, with support for both const and non-const contexts.
 *
 * This function allows dynamic access to elements within a cppon object, which can be either an array or an object,
 * using a string index. The string index can represent either a direct key in an object or a numeric index in an array.
 * 
 * Additionally, it supports hierarchical access to nested elements by interpreting the string index as a path, where segments
 * of the path are separated by slashes ('/'). This allows deep access to nested structures, with the non-const version
 * allowing modification of elements.
 *
 * The function first determines the type of the cppon object (array or object) based on its current state. It then attempts
 * to access the element specified by the index or path. If the element is within a nested structure, the function recursively
 * navigates through the structure to reach the desired element. In the non-const version, any missing elements along the path
 * are created as either objects or arrays, depending on the segment type.
 *
 * Exceptions:
 * - `type_mismatch_error` is thrown if the object is not an array or an object when expected.
 * - In the const version:
 *   - If the key is a path, `member_not_found_error`, `invalid_path_segment_error`, or `type_mismatch_error` may be thrown depending on the path.
 *   - If the key is a numeric value, `member_not_found_error` is thrown for object_t, and `invalid_path_segment_error` may be thrown for array_t.
 *   - When reaching the leaf of the path in an object_t and the member does not exist, it returns the null object, avoiding exceptions for non-existent members in read-only scenarios.
 *   - If the path segment is not a number, `invalid_path_segment_error` is thrown.
 *   - If the index is out of bounds for the array, it returns the null object.
 * - In the non-const version:
 *   - If the path exists and the current segment is a number for object_t, it throws `member_not_found_error` or `type_mismatch_error`.
 *   - If the index is a string segment that does not resolve to a number, it will throw `invalid_path_segment_error`.
 *   - If the index is out of bounds for the array and requires excessive resizing, it throws `excessive_array_resize_error`.
 *
 * This ensures that the caller is informed of incorrect access attempts or structural issues within the cppon object.
 *
 * The const version of this function provides the same functionality but ensures that the operation does not modify the object
 * being dereferenced. It allows dynamic dereferencing of objects in a const context, supporting scenarios where the cppon object
 * structure is accessed in a read-only manner.
 *
 * @param object The cppon object to visit. This object can be an array or an object, and may contain nested structures.
 * 
 * @param index A string representing the index or path to the element to access. This can specify direct access or hierarchical access to nested elements.
 * 
 * @return (const) cppon& A reference to the cppon element at the specified index or path, with the non-const version allowing modification of the element.
 * 
 * @throws type_mismatch_error If the cppon object does not match the expected structure for the specified index or path, indicating a type mismatch or invalid access attempt.
 * @throws member_not_found_error In the specified scenarios, indicating that a specified member in the path does not exist.
 * @throws invalid_path_segment_error In the specified scenarios, indicating that a path segment is invalid or out of bounds.
 * @throws excessive_array_resize_error In the specified scenarios, indicating that excessive array resizing is required.
 */
inline const cppon& visitor(const cppon& object, string_view_t index) {
    return std::visit([&](auto&& arg) -> const cppon& {
        using type = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<type, object_t>)
            return visitor(arg, index);
        if constexpr (std::is_same_v<type, array_t>)
            return visitor(arg, index);
        throw type_mismatch_error{};
    }, static_cast<const value_t&>(object));
}
inline cppon& visitor(cppon& object, string_view_t index) {
    return std::visit([&](auto&& arg) -> cppon& {
        using type = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<type, object_t>)
            return visitor(arg, index);
        if constexpr (std::is_same_v<type, array_t>)
            return visitor(arg, index);
        throw type_mismatch_error{};
    }, static_cast<value_t&>(object));
}

} // namespace cppon

#endif // CPPON_VISITORS_H