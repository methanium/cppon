/*
 * C++ON - High performance C++17 JSON parser with extended features
 * https://github.com/methanium/cppon
 *
 * File: c++on-types.h++ : Core type definitions
 *
 * MIT License
 * Copyright (c) 2023 Manuel Zaccaria (methanium) / CH5 Design
 *
 * See LICENSE file for complete license details
 */

#ifndef CPPON_TYPES_H
#define CPPON_TYPES_H

#include "c++on-alternatives.h"
#include "c++on-exceptions.h"
#include <type_traits>

namespace cppon {

/**
 * @brief Central utilities for managing cppon objects and their interconnections.
 *
 * This suite of utility functions is foundational to the cppon framework, offering mechanisms for managing the root object,
 * handling null values, and processing reference paths during deserialization. These utilities ensure the cppon object hierarchy
 * remains coherent, navigable, and dynamically adaptable, supporting complex data structures and relationships.
 *
 * - `get_root()`, `set_root(cppon&)`, and `reset_root()`: Facilitate the management of the root object, which is pivotal for
 *   resolving reference paths and maintaining the top-level context of the cppon hierarchy. These functions allow for dynamic
 *   adjustments to the root object, accommodating changes in the object hierarchy's structure.
 *
 * - `is_root(const cppon&)` and `is_null_root()`: Offer checks to determine if a given cppon object is the current root or if
 *   the root is set to the null singleton, respectively. These checks are crucial for operations that depend on the position
 *   of objects within the hierarchy.
 *
 * - `visitor(cppon&, size_t)`, `visitor(cppon&, path_t)`, `visitor(const cppon&, size_t)`, and `visitor(const cppon&, path_t)`:
 *   Provide mechanisms to access cppon objects by index or path. These functions are essential for navigating and manipulating
 *   the cppon object hierarchy.
 *
 * Collectively, these utilities underscore the cppon framework's flexibility, robustness, and capability to represent and manage
 * complex data structures and relationships. They are instrumental in ensuring that cppon objects can be dynamically linked,
 * accessed, and manipulated within a coherent and stable framework.
 */
#ifndef CPPON_ROOT_STACK
bool is_root(const cppon& root) noexcept;
void set_root(cppon& root) noexcept;
void reset_root() noexcept;
bool is_null_root() noexcept;
cppon& get_root() noexcept;
class root_guard {
    cppon& old_root;
public:
    root_guard(const cppon& new_root) noexcept
        : old_root(get_root()) {
        set_root(const_cast<cppon&>(new_root));
    }
    ~root_guard() noexcept {
        set_root(old_root);
    }
};
#else
void push_root(const cppon& root);
void pop_root(const cppon& root) noexcept;
class root_guard {
    cppon& new_root;
public:
    root_guard(const cppon& new_root_arg) noexcept
        : new_root(const_cast<cppon&>(new_root_arg)) {
        push_root(new_root);
    }
    ~root_guard() noexcept {
        pop_root(new_root);
    }
};
#endif

cppon& visitor(cppon& object, size_t index);
cppon& visitor(cppon& object, string_view_t index);
const cppon& visitor(const cppon& object, size_t index);
const cppon& visitor(const cppon& object, string_view_t index);

// Type trait to check if a type is contained in a std::variant and is an r-value reference
template<typename T, typename Variant>
struct is_in_variant_rv;

template<typename T, typename... Types>
struct is_in_variant_rv<T, std::variant<Types...>> 
    : std::disjunction<std::is_same<std::decay_t<T>, Types>..., std::is_rvalue_reference<T>> {};

// Type trait to check if a type is contained in a std::variant and is an l-value reference
template<typename T, typename Variant>
struct is_in_variant_lv;

template<typename T, typename... Types>
struct is_in_variant_lv<T, std::variant<Types...>> 
    : std::disjunction<std::is_same<std::decay_t<T>, Types>..., std::negation<std::is_rvalue_reference<T>>> {};

/**
 * @brief The cppon class represents a versatile container for various types used within the cppon framework.
 *
 * This class extends from `value_t`, which is an alias for a `std::variant` that encapsulates all types managed by cppon.
 * It provides several utility functions and operator overloads to facilitate dynamic type handling and hierarchical data
 * structure manipulation.
 *
 * - `is_null()`: Checks if the current instance holds a null value.
 *
 * - `operator[](index_t index)`: Overloaded subscript operators for non-const and const contexts. These operators allow
 *   access to nested cppon objects by index. If the root is null, the current instance is set as the root.
 *
 * - `operator=(const T& val)`: Template assignment operators for copying and moving values into the cppon instance.
 *
 * - `operator=(const char* val)`: Assignment operator for C-style strings, converting them to `string_view_t` before assignment.
 *
 * - `operator=(const string_t& val)`: Assignment operator for `string_t` type.
 *
 * The class leverages `std::visit` to handle the variant types dynamically, ensuring that the correct type-specific
 * operations are performed. This design allows cppon to manage complex data structures and relationships efficiently.
 */

class cppon : public value_t {
public:
    auto is_null() const -> bool {return std::holds_alternative<nullptr_t>(*this);}

    ~cppon() noexcept {
#ifndef CPPON_ROOT_STACK
        if (is_root(*this)) {
            reset_root();
        }
#else
        pop_root(*this);
#endif
    }

    auto operator[](string_view_t index)->cppon& {
        CPPON_ASSERT(!index.empty() && "Index cannot be empty");
        if (index.front() == '/') {
#ifndef CPPON_ROOT_STACK
            set_root(*this);
#else
            push_root(*this);
#endif
            return visitor(get_root(), index.substr(1));
        }
        return visitor(*this, index);
    }

    auto operator[](string_view_t index)const->const cppon& {
        CPPON_ASSERT(!index.empty() && "Index cannot be empty");
        if (index.front() == '/') {
#ifndef CPPON_ROOT_STACK
            set_root(const_cast<cppon&>(*this));
#else
            push_root(*this);
#endif
            return visitor(static_cast<const cppon&>(get_root()), index.substr(1));
        }
        return visitor(*this, index);
    }

    auto operator[](size_t index)->cppon& {
        return visitor(*this, index);
    }

    auto operator[](size_t index)const->const cppon& {
        return visitor(*this, index);
    }

    auto& operator=(const char* val) {value_t::operator=(string_view_t{ val }); return *this;}

    // Template for lvalue references, disabled for types not contained in value_t
    template<
        typename T,
        typename std::enable_if<is_in_variant_lv<const T, value_t>::value, int>::type = 0>
    auto& operator=(const T& val) { value_t::operator=(val); return *this; }

    // Template for rvalue references, disabled for types not contained in value_t
    template<
        typename T,
        typename std::enable_if<is_in_variant_rv<T, value_t>::value, int>::type = 0>
    auto& operator=(T&& val) { value_t::operator=(std::forward<T>(val)); return *this; }
};

/**
 * @brief Importing std::get and std::get_if into the cppon namespace.
 * 
 * This simplifies access to elements within std::variant instances used in the cppon framework.
 * By bringing std::get and std::get_if into the cppon namespace, the syntax for accessing
 * variant elements is cleaner and more readable.
 * This approach enhances code maintainability, especially when working with complex variant types.
 */

#ifndef CPPON_NO_STD_GET_INJECTION
using std::get_if;
using std::get;
#endif

}//namespace cppon

#endif //CPPON_TYPES_H