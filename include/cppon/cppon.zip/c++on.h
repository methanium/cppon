/*
 * C++ON - High performance C++17 JSON parser with extended features
 * https://github.com/methanium/cppon
 *
 * MIT License
 * Copyright (c) 2023 Manuel Zaccaria (methanium) / CH5 Design
 *
 * See LICENSE file for complete license details
 */

#ifndef CPPON_H
#define CPPON_H



/*
 * @brief Configuration macros
 *
 * #define CPPON_NO_SIMD                - Disable SIMD optimizations (for older CPUs)
 * #define CPPON_NO_TRUSTED             - Disable trusted spaces (faster parsing, less secure)
 * #define CPPON_NO_STD_GET_INJECTION   - Disable std::get and std::get_if injection into cppon namespace
 */

#ifndef CPPON_PATH_PREFIX
#define CPPON_PATH_PREFIX "$cppon-path:"
#endif

#ifndef CPPON_BLOB_PREFIX
#define CPPON_BLOB_PREFIX "$cppon-blob:"
#endif

#ifndef CPPON_MAX_ARRAY_DELTA
#define CPPON_MAX_ARRAY_DELTA 100
#endif

#ifndef CPPON_INITIAL_PRINTER_RESERVE_PER_ELEMENT
#define CPPON_INITIAL_PRINTER_RESERVE_PER_ELEMENT 8
#endif

#ifndef CPPON_OBJECT_MIN_RESERVE
#define CPPON_OBJECT_MIN_RESERVE 4
#endif

#ifndef CPPON_ARRAY_MIN_RESERVE
#define CPPON_ARRAY_MIN_RESERVE 4
#endif

#ifndef CPPON_NO_TRUSTED
#define CPPON_USE_TRUSTED 1
#else
#define CPPON_USE_TRUSTED 0
#endif

#ifndef CPPON_NO_SIMD
#define CPPON_USE_SIMD 1
#else
#define CPPON_USE_SIMD 0
#endif







// -----------------------------------------------------------------------------
// SECTION: Platform & SIMD Utilities
// -----------------------------------------------------------------------------
// Platform-adaptive includes and type definitions for CPU feature detection
// and SIMD acceleration. This section provides the necessary low-level
// utilities for high-performance parsing and processing, and ensures
// portability across compilers and architectures.
// Namespaces: platform, simd
// -----------------------------------------------------------------------------

#include "../platform/processor_features_info.h"

#include "../simd/simd_comparisons.h"

// -----------------------------------------------------------------------------
// SECTION: C++ON Core Headers
// -----------------------------------------------------------------------------
// Main C++ON components: exceptions, type alternatives, core types, parser,
// visitors, printer, and references. These headers define the public API and
// all core features of the library.
// -----------------------------------------------------------------------------

#include "c++on-exceptions.h"
#include "c++on-alternatives.h"
#include "c++on-types.h"
#include "c++on-parser.h"
#include "c++on-visitors.h"
#include "c++on-references.h"
#include "c++on-printer.h"

#endif // CPPON_H