/*
 * C++ON - High performance C++17 JSON parser with extended features
 * https://github.com/methanium/cppon
 *
 * File: c++on-alternatives.h++ - Type alternatives and definitions
 *
 * MIT License
 * Copyright (c) 2023 Manuel Zaccaria (methanium) / CH5 Design
 *
 * See LICENSE file for complete license details
 */

#ifndef CPPON_ALTERNATIVES_H
#define CPPON_ALTERNATIVES_H

#include <string>
#include <string_view>
#include <vector>
#include <tuple>
#include <variant>
#include <cmath>

namespace cppon {

#ifndef float_t
    #if defined(__STDC_IEC_559__) || (defined(_MSC_VER) && (defined(_M_X64) || defined(_M_ARM64)))
        using float_t = float; // On x64 and ARM64, float_t is float
    #else
        using float_t = double; // On other architectures, float_t is double
    #endif
#endif
#ifndef double_t
        #if defined(__STDC_IEC_559__) || (defined(_MSC_VER) && (defined(_M_X64) || defined(_M_ARM64)))
        using double_t = double; // On x64 and ARM64, double_t is double
    #else
        using double_t = long double; // On other architectures, double_t is long double
    #endif
#endif

enum class NumberType {
    json_int64,
    json_double,
    cpp_float,
    cpp_int8,
    cpp_uint8,
    cpp_int16,
    cpp_uint16,
    cpp_int32,
    cpp_uint32,
    cpp_int64,
    cpp_uint64
 };

class cppon; // forward declaration for pointer_t, array_t, member_t (object_t)

// Represents a boolean value within the cppon framework.
using boolean_t = bool;

// Represents a pointer to a cppon object.
using pointer_t = cppon*;

// Represents a std::string_view value within the cppon framework.
using string_view_t = std::string_view;

// Represents a string value within the cppon framework.
using string_t = std::string;

// Represents a path value within the cppon framework as a string.
struct path_t {
    std::string_view value;
    path_t(std::string_view v) : value(v) {}
    path_t(const char* v) : value(v) {}
    operator std::string_view() const { return value; }
};

// Represents a numeric text representation within the cppon framework as a string view.
struct number_t {
    std::string_view value;
    NumberType type;
    number_t(std::string_view v, NumberType t) : value(v), type(t) {}
    number_t(const char* v, NumberType t) : value(v), type(t) {}
    operator std::string_view() const { return value; }
};

// Represents a blob encoded as a base64 string within the cppon framework.
// This type is used for efficiently storing binary data in text format using base64 encoding.
struct blob_string_t {
	std::string_view value;
	blob_string_t(std::string_view v) : value(v) {}
    blob_string_t(const char* v) : value(v) {}
	operator std::string_view() const { return value; }
};

// Represents a blob value within the cppon framework as a vector of bytes.
using blob_t = std::vector<uint8_t>;

// Represents an array of cppon objects.
using array_t = std::vector<cppon>;

/**
 * @brief Represents a JSON object in cppon.
 *
 * In cppon, a JSON object is represented by a `std::vector` of members, where members are tuples
 * consisting of a key (`string_view_t`) and a value (`cppon`). This representation was chosen for several
 * key reasons related to performance and flexibility:
 *
 * - **Performance**: `std::vector` provides the fastest access and modification speed for typical JSON object operations.
 * - **Order of Elements**: `std::vector` maintains the insertion order of elements.
 * - **Flexibility**: `std::vector` allows for greater flexibility for operations such as bulk insertion and deletion.
 *
 * Note: This representation may have performance implications when searching for specific keys, as it requires linear search.
 */
using object_t = std::vector<std::tuple<string_view_t, cppon>>;

// Represents a variant type for cppon values.
// This type encapsulates all possible types of values that can be represented in the cppon framework,
// enabling the construction of complex, dynamically typed data structures akin to JSON.
using value_t = std::variant<
    object_t,
    array_t,
    double_t,
    float_t,
    int8_t,
    uint8_t,
    int16_t,
    uint16_t,
    int32_t,
    uint32_t,
    int64_t,
    uint64_t,
    number_t,
    boolean_t,
    string_view_t,
    blob_string_t,
    string_t,
    path_t,
    blob_t,
    pointer_t,
    nullptr_t>;

} // namespace cppon

#endif // CPPON_ALTERNATIVES_H